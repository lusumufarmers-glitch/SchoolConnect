# School Connect

School Connect is a school management and learning Android app.

## Current features
- Welcome page: "Welcome to School Connect by Aggrey Mukonyole"
- School Code selection
- School name shown after selecting a School Code
- Institution login
- Fee balance and reminders
- Exam results
- Exam marketplace — KES 50 example
- Student lessons — KES 100 example
- AI Study Assistant concept
- Staff Help & Support
- Prime — KES 100 daily / KES 3,000 monthly
- GitHub Actions APK build

## Demo school codes
- SC001 — Aggrey Mukonyole Academy
- SC002 — School Connect Secondary School
- SC003 — School Connect Primary School

These are demo values. A production version should load registered schools securely from a backend/database.

## GitHub Actions
Push to `main`, then open **Actions → Build School Connect APK**. The workflow builds a debug APK and uploads it as an artifact named `School-Connect-APK`.
