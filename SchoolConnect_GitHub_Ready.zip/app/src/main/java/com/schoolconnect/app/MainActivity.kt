package com.schoolconnect.app

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val schools = mapOf(
        "SC001" to "Aggrey Mukonyole Academy",
        "SC002" to "School Connect Secondary School",
        "SC003" to "School Connect Primary School"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showWelcomePage()
    }

    private fun showWelcomePage() {
        val layout = createLayout()

        layout.addView(TextView(this).apply {
            text = "Welcome to School Connect"
            textSize = 28f
            setPadding(0, 20, 0, 15)
        })

        layout.addView(TextView(this).apply {
            text = "By Aggrey Mukonyole"
            textSize = 18f
            setPadding(0, 0, 0, 10)
        })

        layout.addView(TextView(this).apply {
            text = "Connect your school, parents and students in one place.\n\nManage fees, exam results, lessons, examinations and AI learning support."
            textSize = 16f
            setPadding(0, 0, 0, 25)
        })

        addButton(layout, "Continue to School Connect") {
            showSchoolSelection()
        }

        addButton(layout, "Staff Help & Support") {
            showStaffSupport()
        }

        setContentView(layout)
    }

    private fun showSchoolSelection() {
        val layout = createLayout()

        layout.addView(TextView(this).apply {
            text = "Select Your School"
            textSize = 26f
            setPadding(0, 0, 0, 20)
        })

        val schoolCodes = schools.keys.toList()
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            schoolCodes
        )
        layout.addView(spinner)

        val schoolName = TextView(this).apply {
            text = "School name will appear here"
            textSize = 18f
            setPadding(0, 20, 0, 20)
        }
        layout.addView(schoolName)

        spinner.onItemSelectedListener =
            object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: android.widget.AdapterView<*>?,
                    view: android.view.View?,
                    position: Int,
                    id: Long
                ) {
                    val code = schoolCodes[position]
                    schoolName.text =
                        "School Code: $code\nSchool Name: ${schools[code]}"
                }

                override fun onNothingSelected(
                    parent: android.widget.AdapterView<*>?
                ) {
                    schoolName.text = ""
                }
            }

        addButton(layout, "Continue to Login") {
            showLogin(schoolCodes[spinner.selectedItemPosition])
        }

        addButton(layout, "Staff Help") {
            showStaffSupport()
        }

        setContentView(layout)
    }

    private fun showLogin(schoolCode: String) {
        val layout = createLayout()
        val schoolName = schools[schoolCode] ?: "Unknown School"

        layout.addView(TextView(this).apply {
            text = "Institution Login"
            textSize = 26f
            setPadding(0, 0, 0, 15)
        })

        layout.addView(TextView(this).apply {
            text = "School Code: $schoolCode\nSchool: $schoolName"
            textSize = 17f
            setPadding(0, 0, 0, 20)
        })

        val admissionNumber = EditText(this).apply {
            hint = "Admission Number"
            inputType = android.text.InputType.TYPE_CLASS_TEXT
        }
        layout.addView(admissionNumber)

        val password = EditText(this).apply {
            hint = "Password"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        layout.addView(password)

        addButton(layout, "Login") {
            if (admissionNumber.text.isEmpty() || password.text.isEmpty()) {
                showMessage(
                    "Login Required",
                    "Please enter your Admission Number and Password."
                )
            } else {
                showDashboard(schoolCode, schoolName)
            }
        }

        addButton(layout, "Staff Help & Support") {
            showStaffSupport()
        }

        setContentView(layout)
    }

    private fun showDashboard(schoolCode: String, schoolName: String) {
        val layout = createLayout()

        layout.addView(TextView(this).apply {
            text = "Welcome, $schoolName"
            textSize = 26f
            setPadding(0, 0, 0, 10)
        })

        layout.addView(TextView(this).apply {
            text = "School Code: $schoolCode"
            textSize = 16f
            setPadding(0, 0, 0, 25)
        })

        addButton(layout, "Fee Balance & Reminders") {
            showMessage("Fee Management", "View student fee balances and send parent reminders.")
        }

        addButton(layout, "Exam Results") {
            showMessage("Exam Results", "View and send student examination results.")
        }

        addButton(layout, "Exam Marketplace — KES 50") {
            showMessage("Exam Marketplace", "Purchase or sell approved examinations.")
        }

        addButton(layout, "Student Lessons — KES 100") {
            showMessage("Lessons", "Manage lessons and student learning materials.")
        }

        addButton(layout, "AI Study Assistant") {
            showMessage("AI Study Assistant", "Students can ask questions and upload JPG or supported files.")
        }

        addButton(layout, "Staff Help & Support") {
            showStaffSupport()
        }

        setContentView(layout)
    }

    private fun showStaffSupport() {
        val layout = createLayout()

        layout.addView(TextView(this).apply {
            text = "Staff Help & Support"
            textSize = 26f
            setPadding(0, 0, 0, 20)
        })

        layout.addView(TextView(this).apply {
            text = "Need help using School Connect?\n\n1. Check that your School Code is correct.\n2. Use the student's Admission Number when required.\n3. Contact your institution administrator for account issues.\n4. Contact School Connect support for technical problems.\n\nSchool Connect\nBy Aggrey Mukonyole"
            textSize = 16f
            setPadding(0, 0, 0, 25)
        })

        addButton(layout, "Back to Welcome") {
            showWelcomePage()
        }

        setContentView(layout)
    }

    private fun createLayout(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 32)
        }
    }

    private fun addButton(
        layout: LinearLayout,
        text: String,
        action: () -> Unit
    ) {
        layout.addView(Button(this).apply {
            this.text = text
            setOnClickListener { action() }
        })
    }

    private fun showMessage(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }
}
