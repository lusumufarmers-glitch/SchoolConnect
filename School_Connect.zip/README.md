# School Connect

Starter Android project structure for a school management and learning platform.

## Included
- Institution registration/login concept using School Code + Admission Number
- Parent fee reminders and exam results
- Exam marketplace (example price KES 50)
- Student lessons (example price KES 100)
- AI study assistant with image/file upload concept
- 5 free file-upload trials, then Prime: KES 100 daily / KES 3,000 monthly
- Backend-ready service interfaces for payments, SMS, and AI

## Important
This is a starter project, not a production payment/SMS/AI service. Real payments, SMS delivery, authentication, file storage, and AI responses require authorized services and backend credentials.
