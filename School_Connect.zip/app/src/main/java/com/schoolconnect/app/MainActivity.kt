package com.schoolconnect.app

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 32)
        }

        fun button(text: String, action: () -> Unit): Button =
            Button(this).apply {
                this.text = text
                setOnClickListener { action() }
            }

        val title = TextView(this).apply {
            text = "School Connect"
            textSize = 30f
            setPadding(0, 0, 0, 20)
        }

        val subtitle = TextView(this).apply {
            text = "School management • Learning • AI Study Assistant"
            textSize = 16f
        }

        layout.addView(title)
        layout.addView(subtitle)

        layout.addView(button("Institution Login") {
            Toast.makeText(this, "School Code + Admission Number login", Toast.LENGTH_SHORT).show()
        })
        layout.addView(button("Fee Reminders & Results") {
            Toast.makeText(this, "Parent notifications module", Toast.LENGTH_SHORT).show()
        })
        layout.addView(button("Exam Marketplace — KES 50") {
            Toast.makeText(this, "Exam marketplace module", Toast.LENGTH_SHORT).show()
        })
        layout.addView(button("Lessons — KES 100") {
            Toast.makeText(this, "Student lessons module", Toast.LENGTH_SHORT).show()
        })
        layout.addView(button("AI Study Assistant") {
            Toast.makeText(this, "5 free file uploads, then Prime", Toast.LENGTH_SHORT).show()
        })
        layout.addView(button("Prime — KES 100 daily / KES 3,000 monthly") {
            Toast.makeText(this, "Prime subscription module", Toast.LENGTH_SHORT).show()
        })

        setContentView(layout)
    }
}
