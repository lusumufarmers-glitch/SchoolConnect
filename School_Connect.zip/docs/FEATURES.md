# School Connect Feature Specification

## Institution
- Registration
- Unique School Code
- Staff login
- Student/admission records
- Fee balances and reminders
- Exam results
- Announcements

## Marketplace
- Upload exam
- Price: KES 50 per exam (configurable)
- Institution purchase history
- Access control after payment

## Lessons
- Price: KES 100 per lesson (configurable)
- Notes/files/images
- Student lesson access

## AI
- Text questions
- JPG/photo questions
- Supported document uploads
- 5 free file uploads
- Prime: KES 100 daily
- Prime: KES 3,000 monthly

## Production integrations needed
- Secure backend/database
- Authorized payment provider
- SMS provider
- AI API
- Cloud file storage
- Secure authentication
- Admin reporting
